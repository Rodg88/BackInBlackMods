Black textures for mods which don't use stock textures.

To install:
Move the folders and configs corresponding to the mods you want to enable black textures on into the main BackInBlack folder in GameData. 